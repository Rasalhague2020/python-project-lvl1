import brain_games.cli
import brain_games.main_loop


def main():
    brain_games.cli.welcome_calc_rules()
    user_name = brain_games.cli.welcome_user()
    brain_games.main_loop.main_loop('calc', user_name)


if __name__ == '__main__':
    main()
