import brain_games.cli

def main():
    print('Welcome to the Brain Games!')
    print()
    brain_games.cli.welcome_user()


if __name__ == '__main__':
    main()